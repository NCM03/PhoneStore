package fa.training.phonestore.service.imp;

import fa.training.phonestore.entity.Category;

import java.util.List;
public interface CategoryServiceImp {



}
