package fa.training.phonestore.service;

import fa.training.phonestore.entity.Category;
import fa.training.phonestore.service.imp.CategoryServiceImp;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CategoryService implements CategoryServiceImp {


}
