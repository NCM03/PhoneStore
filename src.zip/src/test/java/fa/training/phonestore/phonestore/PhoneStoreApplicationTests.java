package fa.training.phonestore.phonestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoneStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
